fx_version 'cerulean'
game 'gta5'

name 'nico.3190'
description 'Vehicle Lockpicking Script by nico.3190'
version '1.0.2'
lua54 'true'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}
